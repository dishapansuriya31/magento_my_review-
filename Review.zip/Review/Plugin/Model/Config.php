<?php
 
namespace Vendor\Modulename\Plugin\Model;
use Magento\Store\Model\StoreManagerInterface;
 
class Config
{
    protected $_storeManager;
 
    public function __construct(
        StoreManagerInterface $storeManager
    )
    {
        $this->_storeManager = $storeManager;
    }
 
    public function afterGetAttributeUsedForSortByArray(\Magento\Catalog\Model\Config $catalogConfig, $options)
    {
        $customOption['A'] = __('A');
        $options = array_merge($customOption, $options);
        return $options;
    }
}