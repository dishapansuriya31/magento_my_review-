<?php
// namespace Kitchen\Company\Plugin;

// use Magento\Customer\Model\CustomerFactory;
// use Magento\Framework\Message\ManagerInterface;

// class ActionPlugin
// {
//     protected $customerFactory;
//     protected $messageManager;

//     public function __construct(
//         CustomerFactory $customerFactory,
//         ManagerInterface $messageManager
//     ) {
//         $this->customerFactory = $customerFactory;
//         $this->messageManager = $messageManager;
//     }

//     public function beforeExecute(
//         \Kitchen\Company\Controller\Staff\Save $subject
//     ) {
//         $data = $subject->getRequest()->getPostValue();
//         if (!$data) {
//             $this->messageManager->addError("No data received.");
//             $subject->getResponse()->setRedirect('*/*/');
//             return;
//         }

//         // Add your code here to modify data before saving if needed
//     }
// }
