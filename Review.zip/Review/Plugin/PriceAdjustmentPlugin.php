<?php
// app/code/Kitchen/Review/Plugin/PriceAdjustmentPlugin.php

namespace Kitchen\Review\Plugin;

class PriceAdjustmentPlugin
{
    protected $cacheTypeList;

    public function __construct(
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList
    ) {
        $this->cacheTypeList = $cacheTypeList;
    }
    

    public function afterGetFinalPrice(
        \Magento\Catalog\Model\Product $subject,
        $result,
        $qty = null
    ) {
        
        $product = $subject->load($subject->getId());
        // Get custom attributes
        $priceType = (float)$product->getData('cp_price_type');
        $prices = (float)$product->getData('cp_price');

        // Adjust price based on custom attributes
        if ((float)$result > 0 && $prices > 0 && in_array($priceType, [0,1])) {
            if ($priceType == 0) {
                $result = (float)$prices; // If price type is 0, return fixed price
            } elseif ($priceType == 1) {
                // If price type is 1, apply percentage discount
                $discount = $prices / 100;
                $discountedPrice = (float)($result - ($result * $discount));
                
                // Set discounted price to result
                $result = min($discountedPrice, $result); // Ensure discounted price doesn't exceed original price
                
                // Set the discounted price to all price types of the product
                $product->setPrice($discountedPrice); // Set the new price
                
               // $product->setFinalPrice($discountedPrice); // Set the final price
               $product->setSpecialPrice(); // Set the special price if applicable

                // You may need to set other price types like special price, tier prices, etc. if applicable
                
                // Save the product
                $product->save();
            }
        }
        return $result; 
    }
}
