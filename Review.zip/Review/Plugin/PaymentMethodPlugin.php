<?php

namespace Kitchen\Review\Plugin;

use Magento\Quote\Model\Quote;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Customer\Model\Session as CustomerSession;

class PaymentMethodPlugin
{
    protected $customerSession;

    public function __construct(
        CustomerSession $customerSession
    ) {
        $this->customerSession = $customerSession;
    }

    public function afterIsAvailable(AbstractMethod $subject, $result)
    {
        // Check if the payment method is available
        if (!$result) {
            return false;
        }

        // Get the customer type
        $customerType = $this->customerSession->getCustomerType();

        // Determine allowed payment methods based on customer type
        $allowedMethods = [];
        switch ($customerType) {
            case 'general':
                $allowedMethods = ['specific_payment_method_code']; // Add more methods as needed
                break;
            // case 'retail':
            //     $allowedMethods = ['another_specific_method_code']; // Add more methods as needed
            //     break;
            // Add cases for other customer types
        }

        // If the current payment method is not in the allowed methods list, return false
        if (!in_array($subject->getCode(), $allowedMethods)) {
            return false;
        }

        return $result;
    }
}
