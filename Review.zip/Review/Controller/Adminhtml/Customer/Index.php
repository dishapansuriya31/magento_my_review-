<?php
namespace Kitchen\Review\Controller\Adminhtml\Customer;



class Index extends \Magento\Backend\App\Action
{
	protected $resultPageFactory = false;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
	{
		$resultPage = $this->resultPageFactory->create();
		$resultPage->getConfig()->getTitle()->prepend((__('Posts')));
        $resultPage->setActiveMenu('Kitchen_Review::review_grid');
        $resultPage->addBreadcrumb(__('grid'), __('grid'));
        $resultPage->addBreadcrumb(__('my review'), __('my review'));

		return $resultPage;
	}


}