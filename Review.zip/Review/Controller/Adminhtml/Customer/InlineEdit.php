<?php
 
namespace Kitchen\Review\Controller\Adminhtml\Customer;
 
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Kitchen\Review\Model\CustomersFactory;
use Kitchen\Review\Model\ResourceModel\Customers as CustomersResourceModel;
 
class InlineEdit extends \Magento\Backend\App\Action
{
    protected $jsonFactory;
    private $CustomersFactory;
    private $CustomersResourceModel;
 
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        CustomersFactory $CustomersFactory,
        CustomersResourceModel $CustomersResourceModel
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->CustomersFactory = $CustomersFactory;
        $this->CustomersResourceModel = $CustomersResourceModel;
    }
 
    public function execute()
{
    $resultJson = $this->jsonFactory->create();
    $error = false;
    $messages = [];

    if ($this->getRequest()->getParam('isAjax')) {
        $postItems = $this->getRequest()->getParam('items', []);
        if (!count($postItems)) {
            $messages[] = __('Please correct the data sent.');
            $error = true;
        } else {
            foreach ($postItems as $modelId => $data) {
                try {
                    $model = $this->CustomersFactory->create()->load($modelId);
                    if (!$model->getId()) {
                        $messages[] = __("The customer with ID %1 does not exist.", $modelId);
                        $error = true;
                        continue;
                    }
                    $model->addData($data);
                    $model->save();
                } catch (\Exception $e) {
                    $messages[] = __("Error occurred while saving customer with ID %1: %2", $modelId, $e->getMessage());
                    $error = true;
                }
            }
        }
    }

    return $resultJson->setData([
        'messages' => $messages,
        'error' => $error
    ]);
}

}