<?php
 
namespace Kitchen\Review\Controller\Adminhtml\Page;
 
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Kitchen\Review\Model\ReviewsFactory;
use Kitchen\Review\Model\ResourceModel\Reviews as ReviewsResourceModel;
 
class InlineEdit extends \Magento\Backend\App\Action
{
    protected $jsonFactory;
    private $ReviewsFactory;
    private $reviewsResourceModel;
 
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        ReviewsFactory $ReviewsFactory,
        ReviewsResourceModel $reviewsResourceModel
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->ReviewsFactory = $ReviewsFactory;
        $this->reviewsResourceModel = $reviewsResourceModel;
    }
 
    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];
 
        if ($this->getRequest()->getParam('isAjax'))
        {
            $postItems = $this->getRequest()->getParam('items', []);
            if (!count($postItems))
            {
                $messages[] = __('Please correct the data sent.');
                $error = true;
            }
            else
            {
                foreach (array_keys($postItems) as $modelid)
                {
                    $model = $this->ReviewsFactory->create();
                    $this->reviewsResourceModel->load($model, $modelid);
                    $model->setData(array_merge($model->getData(), $postItems[$modelid]));
                    $this->reviewsResourceModel->save($model);
                }
            }
        }
 
        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }  
}