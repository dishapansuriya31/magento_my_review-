<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Kitchen\Review\Controller\Adminhtml\Page;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Kitchen\Review\Model\ReviewsFactory;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * Save CMS page action.
 */
class Save extends Action implements HttpPostActionInterface
{
    /**
     * Authorization level of a basic admin session
     */
    const ADMIN_RESOURCE = 'Kitchen_Review::rating_page';

    /**
     * @var PostDataProcessor
     */
    protected $dataProcessor;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var ReviewsFactory
     */
    private $reviewsFactory;

    /**
     * @param Action\Context $context
     * @param ReviewsFactory $reviewsFactory
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Action\Context $context,
        ReviewsFactory $reviewsFactory,
        DataPersistorInterface $dataPersistor
    ) {
        parent::__construct($context);
        $this->reviewsFactory = $reviewsFactory;
        $this->dataPersistor = $dataPersistor;
    }

    /**
     * Save action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            $model = $this->reviewsFactory->create();

            $id = $this->getRequest()->getParam('k_id');
            if ($id) {
                try {
                    $model->load($id);
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage(__('This page no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
            }

            $model->setData($data);

            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('data save successfully.'));
                $this->dataPersistor->clear('review_page');
                return $resultRedirect->setPath('review/index/index');
            } catch (LocalizedException $e) {
                $this->messageManager->addExceptionMessage($e->getPrevious() ?: $e);
            } catch (\Throwable $e) {
                $this->messageManager->addErrorMessage(__('Something went wrong .'));
            }

            $this->dataPersistor->set('review_page', $data);
            return $resultRedirect->setPath('review/page/edit', ['k_id' => $this->getRequest()->getParam('k_id')]);
        }
        return $resultRedirect->setPath('review/index/index');
    }
}
