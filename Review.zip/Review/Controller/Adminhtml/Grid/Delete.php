<?php
namespace Kitchen\Review\Controller\Adminhtml\Grid;

use Magento\Backend\App\Action;
use Kitchen\Review\Model\ReviewsFactory;
use Magento\Framework\Exception\LocalizedException;

class Delete extends Action
{
    protected $reviewsFactory;

    public function __construct(
        Action\Context $context,
        ReviewsFactory $reviewsFactory
    ) {
        parent::__construct($context);
        $this->reviewsFactory = $reviewsFactory;
    }

    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {
                $model = $this->reviewsFactory->create();
                $model->load($id);
                $model->delete();
                $this->messageManager->addSuccessMessage(__('Review has been deleted successfully.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('An error occurred while deleting the review.'));
            }
        } else {
            $this->messageManager->addErrorMessage(__('Unable to find the review to delete.'));
        }

        // Redirect back to grid
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('review/grid/index');
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Kitchen_Review::review_grid');
    }
}
