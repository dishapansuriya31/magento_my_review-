<?php
 
namespace Kitchen\Review\Controller\Adminhtml\Grid;
 
use Magento\Backend\App\Action;
use Magento\Backend\Model\Auth\Session;
 
class Save extends \Magento\Backend\App\Action
{
 
    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $_adminSession;
 
   
    protected $ReviewsFactory;
 
   
    public function __construct(
        Action\Context $context,
        \Magento\Backend\Model\Auth\Session $adminSession,
        \Kitchen\Review\Model\ReviewsFactory $reviewsFactory
    ) {
        parent::__construct($context);
        $this->_adminSession = $adminSession;
        $this->reviewsFactory = $reviewsFactory;
    }
 
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        // echo "<pre>";
        // print_r($data);
        //  die;
 
        if ($data) {
            try {
                if (!empty($data['k_id'])) {
                    $model = $this->reviewsFactory->create()->load($data['k_id']);
                } else {
                    $model = $this->reviewsFactory->create();
                }
 
                $model->setName($data['name']);
                $model->setDescription($data['description']);
                $model->setRating($data['rating']);
                $model->setAdminId($data['admin_id']);
 
                $model->setIsActive($data['is_active']);
 
                $model->save();
                // $this->messageManager->addSuccessMessage(__('User data has been saved.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('Something went wrong while saving the user data.'));
            }
            return $resultRedirect->setPath('review/grid/index');
        }
        return $resultRedirect->setPath('review/grid/index');
    }
}