<?php

namespace Kitchen\Review\Controller\Index;

class Tasks extends \Magento\Framework\App\Action\Action
{

	public function execute()
	{
		$textDisplay = new \Magento\Framework\DataObject(array('text' => 'Reviews'));
		$this->_eventManager->dispatch('controller_action_review', ['event_text' => $textDisplay]);
		echo $textDisplay->getText();
		exit;
	}
}
