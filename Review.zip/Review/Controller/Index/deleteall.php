<?php

namespace Kitchen\Review\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Kitchen\Review\Model\ResourceModel\Reviews\CollectionFactory;
use Magento\Framework\Controller\ResultFactory;

class DeleteAll extends Action
{
    protected $collectionFactory;

    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $ids = $this->getRequest()->getParam('delete_ids');
        if (!is_array($ids)) {
            $this->messageManager->addError(__('Please select item(s) to delete.'));
        } else {
            try {
                $collection = $this->collectionFactory->create();
                $collection->addFieldToFilter('k_id', ['in' => $ids]);
                foreach ($collection as $item) {
                    $item->delete();
                }
                $this->messageManager->addSuccess(__('Selected items have been deleted.'));
            } catch (\Exception $e) {
                $this->messageManager->addError(__('Error occurred while deleting selected items.'));
            }
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('review/index/index');
    }
}
