<?php
// app/code/Kitchen/Review/Controller/Delete.php


namespace Kitchen\Review\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Kitchen\Review\Model\ReviewsFactory;
use Magento\Framework\Message\ManagerInterface;

class Delete extends Action
{
    protected $reviewsFactory;
    protected $messageManager;

    public function __construct(
        Context $context,
        ReviewsFactory $reviewsFactory,
        ManagerInterface $messageManager
    ) {
        $this->reviewsFactory = $reviewsFactory;
        $this->messageManager = $messageManager;
        parent::__construct($context);
    }
    
    public function execute()
    {
        $id = $this->getRequest()->getParam("deleteid");
        try {
            $model = $this->reviewsFactory->create()->load($id);
            if (!$model->getId()) {
                throw new \Exception(__('Record not found.'));
            }
            $model->delete();
            $this->messageManager->addSuccessMessage(__('Data has been deleted.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
        return $this->_redirect('review/index/index');
    }
}
?>