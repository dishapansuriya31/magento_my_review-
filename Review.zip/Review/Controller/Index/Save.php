<?php
 
namespace Kitchen\Review\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Kitchen\Review\Model\ReviewsFactory;
 
class Save extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $collection;
    protected $messageManager;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Kitchen\Review\Model\ReviewsFactory $collection,
        \Magento\Framework\Message\ManagerInterface $messageManager
    ) {
        
        $this->collection = $collection;
        $this->messageManager = $messageManager;
        return parent::__construct($context);
    }
    public function execute(){

        $data = $this->getRequest()->getPostValue();
        $model = $this->collection->create();
      
       // $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        
        // Filter parameters
        $filterParams = [];
        if (!empty($data['name'])) {
            $filterParams['name'] = $data['name'];
        }
        if (isset($data['is_active'])) {
            $filterParams['is_active'] = $data['is_active'];
        }
        
        // Redirect to the index page with filter parameters
      
        if (empty($data['name'])) {
            $this->messageManager->addError(__('Please fill in all required fields.'));
            $this->_redirect('review/index/index');
            return;
        }
        if (!empty($data['edit_id'])) {
            $model->load($data['edit_id']);
        }

       

        if((!empty($data['edit_id']))) {
            $model->load($data['edit_id']);
        }
            $model->setName($data["name"]);
            $model->setRating($data["rating"]);
            $model->setDescription($data["description"]);
            $model->setIsActive($data["is_active"]);
            $model->setAdminId($data["admin_id"]);
            $model->save();
        if(!empty($data['edit_id'])) {
            $this->messageManager->addSuccess(__("Updated Successfully."));
        }   
        else {
            $this->messageManager->addSuccess(__("Saved Successfully."));
        }
        $this->_redirect('review/index/index');
    }
    }
