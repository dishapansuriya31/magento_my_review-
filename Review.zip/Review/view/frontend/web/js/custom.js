require(['jquery'], function($) {
    $(document).ready(function() {
        $('.details-toggle').click(function() {
            $(this).next('.details-content').slideToggle();
        });
    });
});
// define([
//     'jquery'
// ], function ($) {
//     'use strict';

//     return function (config) {
//         $(document).ready(function () {
//             // Your AJAX request code here
//             $.ajax({
//                 url: config.ajaxUrl,
//                 method: 'POST',
//                 dataType: 'json',
//                 data: {
//                     // Your data to send
//                 },
//                 success: function (response) {
//                     // Handle successful response
//                 },
//                 error: function (xhr, status, error) {
//                     // Handle error
//                 }
//             });
//         });
//     };
// });

