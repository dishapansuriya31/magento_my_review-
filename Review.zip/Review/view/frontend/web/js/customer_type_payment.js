require(['jquery'], function($) {
    $(document).ready(function() {
        // Function to show or hide payment methods based on customer type
        function togglePaymentMethods(customerType) {
            // Get the selected customer type
            var selectedCustomerType = $('#customer').val();

            // Hide all payment methods
            $('.payment-method').hide();

            // Show payment methods based on customer type
            if (selectedCustomerType === 'general') {
                $('.general-payment-method').show();
            } else {
                // Handle other customer types if needed
            }
        }

        // Initial toggle based on selected customer type
        togglePaymentMethods();

        // Listen for changes to the customer type field
        $('#customer').change(function() {
            togglePaymentMethods();
        });
    });
});
