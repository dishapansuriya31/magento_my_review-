<?php
// app/code/Kitchen/Review/Block/Task.php

namespace Kitchen\Review\Block;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;  

class Getdata extends \Magento\Framework\View\Element\Template
{
    
    protected $scopeConfig;

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig
       
    ) {
       
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);

    }
    public function isModuleEnable()    {
       return $this->scopeConfig->getValue("info1/promotion/p_enable", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
    }
    
    public function title()    {
        return $this->scopeConfig->getValue("info1/promotion/p_Title", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
     }
     
     public function description() {
        return $this->scopeConfig->getValue("info1/promotion/p_Desc", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
    }

    public function start() {
        return $this->scopeConfig->getValue("info1/promotion/p_startDate", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
    }

    public function end() {
        return $this->scopeConfig->getValue("info1/promotion/p_endDate", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;

    }

    public function isactive() {
        return $this->scopeConfig->getValue("info1/promotion/p_isActive", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;

    }
}
