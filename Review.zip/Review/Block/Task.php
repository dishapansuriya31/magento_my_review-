<?php
// app/code/Kitchen/Review/Block/Task.php

namespace Kitchen\Review\Block;

use Magento\Framework\View\Element\Template\Context;
use Kitchen\Review\Model\ResourceModel\Reviews\CollectionFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class Task extends \Magento\Framework\View\Element\Template
{
    protected $reviewsFactory;
    protected $urlBuilder;
    protected $editId;
    protected $reviewData;
    protected $request;
    protected $timezoneInterface;

    public function __construct(
        Context $context,
        CollectionFactory $reviewsFactory,
        UrlInterface $urlBuilder,
        Http $request,
        TimezoneInterface $timezoneInterface,
        array $data = []
    ) {
        $this->reviewsFactory = $reviewsFactory;
        $this->urlBuilder = $urlBuilder;
        $this->request = $request;
        $this->timezoneInterface = $timezoneInterface; // Injected here

        $this->editId = $this->request->getParam('edit_id');
        parent::__construct($context, $data);
    }

    public function show()
    {
        // Retrieve filter parameters
        $filterParams = $this->getRequest()->getParams();

        // Create collection
        $collection = $this->reviewsFactory->create();

        $sortField = isset($filterParams['sort']) ? $filterParams['sort'] : 'name';
        $sortOrder = isset($filterParams['order']) ? $filterParams['order'] : 'asc';
        $collection->setOrder($sortField, $sortOrder);

        // Apply filters
        if (!empty($filterParams['name'])) {
            $collection->addFieldToFilter('name', ['like' => '%' . $filterParams['name'] . '%']);
        }
        if (isset($filterParams['is_active'])) {
            $collection->addFieldToFilter('is_active', $filterParams['is_active']);
        }

        // Iterate through the collection and display data
        foreach ($collection as $item) {
            echo "<tr>";
            echo '<td><input type="checkbox" name="delete_ids[]" value="' . $item->getKId() . '"></td>';
            echo "<td>".$item->getKId()."</td>";
            echo "<td>".$item->getName()."</td>";
            echo "<td>".$item->getDescription()."</td>";
            echo "<td>".$item->getRating()."</td>";
            echo "<td>".$item->getIsActive()."</td>";
            echo "<td>".$item->getCreationTime()."</td>";
            echo "<td>".$item->getUpdateTime()."</td>";
            echo "<td><a href='".$this->urlBuilder->getUrl('review/index/index', ['edit_id' => $item->getKId()])."'>Edit</a></td>";
            echo "<td><button onclick=\"window.location='".$this->urlBuilder->getUrl('review/index/delete', ['deleteid' => $item->getKId()])."'\">Delete</button></td>";

            echo "</tr>";
        }
    }

    public function getReviewData()
    {
        $editId = $this->getRequest()->getParam('edit_id');
        if ($editId) {
            $review = $this->reviewsFactory->create()->load($editId);
            return $review->getData();
        }
        return [];
    }
    public function getKId()
    {
        return $this->editId;
    }

    public function sayHello()
    {
        return __('Hello World');
    }
    public function _prepareLayout()
    {
        // $this->pageConfig->getTitle()->prepend(__('review') . ' ' . $this->timezoneInterface->date()->format('Y-m-d H:i:s'));

        $breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs');
        $baseUrl = $this->_storeManager->getStore()->getBaseUrl();
 
        if ($breadcrumbsBlock) {
 
            $breadcrumbsBlock->addCrumb(
                'home',
                [
                'label' => __('Home'), //lable on breadCrumbes
                'title' => __('Home'),
                'link' => $baseUrl
                ]
            );
            $breadcrumbsBlock->addCrumb(
                'review',
                [
                'label' => __('Review'), //lable on breadCrumbes
                'title' => __('Review'),
                'link' => ''
                ]
            );
        }
        $currentTime = $this->timezoneInterface->date()->format('Y-m-d H:i:s');
        $this->pageConfig->getTitle()->prepend(__('Review') . ' ' . $currentTime);

      //  $this->pageConfig->getTitle()->set(__('Review')); // set page name
        return parent::_prepareLayout();
    }
}
