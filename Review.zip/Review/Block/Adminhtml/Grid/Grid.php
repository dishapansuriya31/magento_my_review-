<?php
namespace Kitchen\Review\Block\Adminhtml\Grid;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Helper\Data as BackendHelper;
use Kitchen\Review\Model\ReviewsFactory;

use Kitchen\Review\Model\ResourceModel\Reviews\CollectionFactory as ReviewsCollectionFactory;
use Magento\Framework\Registry;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    protected $_reviewsFactory;
    protected $_reviewsCollectionFactory;
    protected $_coreRegistry;
 
    public function __construct(

//\Kitchen\Review\Helper\Data $reviewData,
        Context $context,
        BackendHelper $backendHelper,
        ReviewsFactory $reviewsFactory,
        ReviewsCollectionFactory $reviewsCollectionFactory,
        Registry $coreRegistry,
        array $data = []
    ) {
        $this->_reviewsFactory = $reviewsFactory;
        $this->_reviewsCollectionFactory = $reviewsCollectionFactory;
        $this->_coreRegistry = $coreRegistry;
      //  $this->_reviewData = $reviewData;
       

        parent::__construct($context, $backendHelper, $data);
    }

    protected function _construct()
    {
        parent::_construct();
        $this->setId('k_id');
        $this->setDefaultSort('creation_time');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }

    protected function _prepareCollection()
    {
        $collection = $this->_reviewsCollectionFactory->create();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $model = $this->_coreRegistry->registry('review_form_data');

        $isElementDisabled = false;

     //   $form = $this->_formFactory->create();
      //  $form->setHtmlIdPrefix('page_');

       // $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Blog Information')]);
        $this->addColumn(
            'k_id',
            [
                'header' => __('ID'),
                'index' => 'k_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id',
                'sortable' => true,
            ]
        );

        $this->addColumn(
            'name',
            [
                'header' => __('Name'),
                'index' => 'name',
                'type' => 'text',
                'escape' => true,
                'sortable' => true,
            ]
        );

        $this->addColumn(
            'description',
            [
                'header' => __('description'),
                'index' => 'description'
            ]
        );
        $this->addColumn(
            'is_active',
            [
                'header' => __('is_active'),
                'index' => 'is_active',
                'type' => 'options',
                'options' => ['0' => __('InActive'), '1' => __('Active')]
            ]
        );

       

        $this->addColumn(
            'rating',
            [
                'header' => __('Rating'),
                'index' => 'rating',
                
            ]
        );

        $this->addColumn(
            'creation_time',
            [
                'header' => __('Created At'),
                'index' => 'creation_time',
                'type' => 'datetime'
            ]
        );
        $this->addColumn(
            'update_time',
            [
                'header' => __('Updated At'),
                'index' => 'update_time',
                'type' => 'datetime'
            ]
        );

        

        $this->addColumn(
            'action',
            [
                'header' => __('Action'),
                'type' => 'action',
                'getter' => 'getKId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => ['base' => 'review/grid/edit'],
                        'field' => 'k_id'
                    ],
                    [
                        'caption' => __('Delete'),
                        'url' => ['base' => 'review/grid/delete'],
                        'field' => 'k_id',
                        'confirm' => [
                            'description' => __('Delete'),
                            'message' => __('Are you sure you want to delete this record?')
                        ]
                    ]
                ],
                'filter' => false,
                'sortable' => false,
                'index' => 'reviews',
                'header_css_class' => 'col-action',
                'column_css_class' => 'col-action'
            ]
        );
        
        $block = $this->getLayout()->getBlock('grid.bottom.links');

        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('k_id');
        $this->setMassactionIdFilter('k_id');
        $this->setMassactionIdFieldOnlyIndexValue(true);
        $this->getMassactionBlock()->setFormFieldName('reviews');
    
        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl('review/grid/massdelete'), // Corrected URL
                'confirm' => __('Are you sure?')
            ]
        );
    
        //$statuses = $this->_reviewData->getReviewStatusesOptionArray();
        // array_unshift($statuses, ['label' => '', 'value' => '']);
    }
  protected function _prepareMassactionColumn()
    {
        parent::_prepareMassactionColumn();
        /** needs for correct work of mass action select functionality */
        $this->setMassactionIdField('k_id');
 
        return $this;
    }
    public function getGridUrl()
    {
        return $this->getUrl('review/grid/grid', ['_current' => true]);
    }

    /**
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl('review/grid/edit', ['k_id' => $row->getId()]);
    }
    }
