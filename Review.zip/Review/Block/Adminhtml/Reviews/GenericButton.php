<?php
namespace Kitchen\Review\Block\Adminhtml\Reviews;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class GenericButton implements ButtonProviderInterface
{
    public function getButtonData()
    {
        return [];
    }
    
}
