<?php
// app/code/Vendor/Module/Block/CustomBlock.php

namespace Kitchen\Review\Block;

use Magento\Framework\View\Element\Template;

class CustomBlock extends Template
{
    protected $_productCollectionFactory;

    public function __construct(
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        Template\Context $context,
        array $data = []
    ) {
        $this->_productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $data);
    }

    public function getProductCollection()
    {
        return $this->_productCollectionFactory->create();
    }

    public function getLayer()
    {
        return $this->getData('layer');
    }
}
