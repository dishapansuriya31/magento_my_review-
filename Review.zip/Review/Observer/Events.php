<?php

namespace Kitchen\Review\Observer;

class Events implements \Magento\Framework\Event\ObserverInterface {
    /**
     * @var Request
     */
    protected $request;

    public function __construct(
        \Magento\Framework\App\Request\Http $request   
    ) {
        $this->request = $request;
    }
    public function execute(\Magento\Framework\Event\Observer $observer){
         echo ($this->request->getModuleName() .'_'.$this->request->getControllerName() .'_'.$this->request->getActionName() );
        // echo "<pre>";
        // print_r(get_class_methods($this->request));
    }
}