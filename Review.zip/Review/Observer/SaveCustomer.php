<?php
namespace Kitchen\Review\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Kitchen\Review\Model\AddressesFactory;
use Magento\Framework\App\RequestInterface;

class SaveCustomer implements ObserverInterface
{
    protected $customerRepository;
    protected $cpaddressesFactory;
    protected $request;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        AddressesFactory $cpaddressesFactory,
        RequestInterface $request
    ) {
        $this->customerRepository = $customerRepository;
        $this->cpaddressesFactory = $cpaddressesFactory;
        $this->request = $request;
    }

    public function execute(Observer $observer)
    {

        
        $kstreet = $this->request->getParam('kstreet');
        $kcity = $this->request->getParam('kcity');
        $kregion = $this->request->getParam('kregion');
        $kpostcode = $this->request->getParam('kpostcode');
        $kcountry = $this->request->getParam('kcountry');
        $mobile = $this->request->getParam('mobile');
        $customer = $observer->getEvent()->getCustomer();
        $customerID = $customer->getId();

        
        $this->saveToCustomTable($kstreet, $kcity, $kregion, $kpostcode, $kcountry, $customerID, $mobile);
    }

    protected function saveToCustomTable($kstreet, $kcity, $kregion, $kpostcode, $kcountry, $customerID, $mobile)
    {
        $addressModel = $this->cpaddressesFactory->create();
        $addressModel->setStreet($kstreet);
        $addressModel->setCity($kcity);
        $addressModel->setRegion($kregion);
        $addressModel->setPostcode($kpostcode);
        $addressModel->setCountry($kcountry);
        $addressModel->setCustomerId($customerID);
        $addressModel->setMobile($mobile);
        $addressModel->save();
    }
}
 


