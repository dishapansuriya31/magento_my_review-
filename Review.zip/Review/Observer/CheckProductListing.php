<?php

namespace Kitchen\Review\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class CheckProductListing implements ObserverInterface
{
    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var RedirectInterface
     */
    protected $redirect;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * Constructor
     *
     * @param CustomerSession $customerSession
     * @param RedirectInterface $redirect
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        CustomerSession $customerSession,
        RedirectInterface $redirect,
        CustomerRepositoryInterface $customerRepository
    ) {
        $this->customerSession = $customerSession;
        $this->redirect = $redirect;
        $this->customerRepository = $customerRepository;
    }

    /**
     * Check if the customer has access to the product listing page
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $customerId = $this->customerSession->getCustomerId();
        if ($customerId) {
            try {
                $customer = $this->customerRepository->getById($customerId);
                $productListingAttribute = $customer->getCustomAttribute('Product_listing');
                if ($productListingAttribute && $productListingAttribute->getValue() == 0) {
                    // Customer does not have access to the product listing page
                    $this->redirect->redirect($observer->getControllerAction()->getResponse());
                }
            } catch (\Exception $e) {
                // Handle exception
            }
        }
    }
}
