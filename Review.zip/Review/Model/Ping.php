<?php

namespace Kitchen\Review\Model;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;
 
class Ping extends Command
{
    protected $customerCollectionFactory;
 
    public function __construct(CollectionFactory $customerCollectionFactory)
    {
        $this->customerCollectionFactory = $customerCollectionFactory;
        parent::__construct();
    }
 
    protected function configure()
    {
        $this->setName('Disha:ping')
            ->setDescription('Ping us to support!');
    }
 
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln('Need Help Contact To Disha!');
 
        // Get customer IDs
        $customerCollection = $this->customerCollectionFactory->create();
        $customerIds = $customerCollection->getAllIds();
 
        // Output customer IDs
        $output->writeln('Customer IDs: ' . implode(', ', $customerIds));
        return 0;
    }
}