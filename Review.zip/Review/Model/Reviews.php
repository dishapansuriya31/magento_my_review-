<?php

namespace Kitchen\Review\Model;

class Reviews extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\Review\Model\ResourceModel\Reviews::class);
    }
}
