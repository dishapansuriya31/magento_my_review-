<?php
namespace Kitchen\Review\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class BatterySource extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        // Your custom logic to fetch options
        return [
            ['value' => 0, 'label' => __('15w')],
            ['value' => 1, 'label' => __('32w')],
            ['value' => 2, 'label' => __('101w')],
            // Add more options as needed
        ];
    }
}
?>