<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kitchen\Review\Model\Config\Source;

/**
 * Configuration source model for Wysiwyg toggling
 */
class IsActive implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            ['value' => 0, 'label' => __('InActive')],
            ['value' => 1, 'label' => __('Active')]
        ];
    }
}
