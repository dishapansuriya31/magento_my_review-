<?php
 
namespace Kitchen\Review\Model\Config\Source;
 
class CustomerType implements \Magento\Framework\Option\ArrayInterface

{
protected $_options;
 
public function __construct(\Magento\Customer\Model\ResourceModel\Group\CollectionFactory $groupCollectionFactory)
{
    $this->_groupCollectionFactory = $groupCollectionFactory;
}
 
/**
* @return array
*/
public function toOptionArray()
{
    if (!$this->_options) {
        $this->_options = $this->_groupCollectionFactory->create()->loadData()->toOptionArray();
    }
    return $this->_options;
}
}