<?php
namespace Kitchen\Review\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class Custom extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        // Your custom logic to fetch options
        return [
            ['value' => 0, 'label' => __('25GB')],
            ['value' => 1, 'label' => __('12GB')],
            ['value' => 2, 'label' => __('6GB')],
            // Add more options as needed
        ];
    }
}
?>