<?php
namespace Kitchen\Review\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Hobbies implements OptionSourceInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'reading', 'label' => __('Reading')],
            ['value' => 'cooking', 'label' => __('Cooking')],
            ['value' => 'gardening', 'label' => __('Gardening')],
            ['value' => 'painting', 'label' => __('Painting')],
            ['value' => 'music', 'label' => __('Listening to Music')],
          
        ];
    }
}
