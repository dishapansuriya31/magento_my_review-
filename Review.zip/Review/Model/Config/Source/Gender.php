<?php

namespace Kitchen\Review\Model\Config\Source;


class Gender implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Female', 'label' => __('Female')],
            ['value' => 'Male', 'label' => __('Male')]
        ];
    }
}
