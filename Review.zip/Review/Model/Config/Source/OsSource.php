<?php
namespace Kitchen\Review\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class OsSource extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        // Your custom logic to fetch options
        return [
            ['value' => 0, 'label' => __('Multi-Processing ')],
            ['value' => 1, 'label' => __('Multi-Tasking')],
            ['value' => 2, 'label' => __('Distributed')],
            // Add more options as needed
        ];
    }
}
?>