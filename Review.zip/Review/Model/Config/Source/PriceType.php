<?php
namespace Kitchen\Review\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class PriceType extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        // Your custom logic to fetch options
        return [
            ['value' => 0, 'label' => __('Fix')],
            ['value' => 1, 'label' => __('Pecentage')],
          
            // Add more options as needed
        ];
    }
}
?>