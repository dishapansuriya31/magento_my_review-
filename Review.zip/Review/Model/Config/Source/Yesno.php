<?php
namespace Kitchen\Review\Model\Config\Source;

use Kitchen\Review\Model\CustomersFactory;

class Yesno implements \Magento\Framework\Option\ArrayInterface
{
    protected $customersFactory;
 
    public function __construct(
        CustomersFactory $customersFactory
    ) {
        $this->customersFactory = $customersFactory;
    }
 
    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => 'Yes'],
            ['value' => '1', 'label' => 'No']
        ];
    }
 
    
}
