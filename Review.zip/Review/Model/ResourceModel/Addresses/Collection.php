<?php

namespace Kitchen\Review\Model\ResourceModel\Addresses;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'entity_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Review\Model\Addresses::class,
            \Kitchen\Review\Model\ResourceModel\Addresses::class
        );
    }
}
