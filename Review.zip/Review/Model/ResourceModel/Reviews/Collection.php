<?php

namespace Kitchen\Review\Model\ResourceModel\Reviews;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'k_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Review\Model\Reviews::class,
            \Kitchen\Review\Model\ResourceModel\Reviews::class
        );
    }
}
