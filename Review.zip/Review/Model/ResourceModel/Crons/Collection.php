<?php

namespace Kitchen\Review\Model\ResourceModel\Crons;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'schedule_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Review\Model\Crons::class,
            \Kitchen\Review\Model\ResourceModel\Crons::class
        );
    }
}
