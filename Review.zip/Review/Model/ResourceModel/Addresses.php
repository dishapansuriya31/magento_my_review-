<?php

namespace Kitchen\Review\Model\ResourceModel;

class Addresses extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('kitchen_customer_address', 'entity_id');
    }
}
