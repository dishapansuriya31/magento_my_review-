<?php

namespace Kitchen\Review\Model\ResourceModel\Customers;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'customer_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Review\Model\Customers::class,
            \Kitchen\Review\Model\ResourceModel\Customers::class
        );
    }
}
