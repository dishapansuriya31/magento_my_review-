<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Kitchen\Review\Model;

/**
 * Service Data Object with Page search results.
 */
class PageSearchResults implements \Kitchen\Review\Api\PageRepositoryInterface
{
    public function getreview()
    {
        echo 11;die;
    }
}
