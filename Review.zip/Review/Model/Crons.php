<?php

namespace Kitchen\Review\Model;

class Crons extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\Review\Model\ResourceModel\Crons::class);
    }
}
