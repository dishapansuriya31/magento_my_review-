<?php

namespace Kitchen\Review\Cron;

use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory;

class SampleCron {
    /**
     * @var CollectionFactory
     */
    protected $customerCollectionFactory;
    protected $transportBuilder;
    protected $inlineTranslation;

    /**
     * Testcron constructor.
     * @param CollectionFactory $customerCollectionFactory
     */
    public function __construct(
        CollectionFactory $customerCollectionFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder, 
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
         \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig

    ) {
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->customerCollectionFactory = $customerCollectionFactory;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Retrieve customer collection and do something with it
     *
     * @return void
     */
    public function execute() {
        $customerCollection = $this->customerCollectionFactory->create();
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1); 
        $templateVars = []; 
        $this->inlineTranslation->suspend(); 
        foreach ($customerCollection as $customer) {
            $customerId = $customer->getId();
              $customerEmail = $customer->getEmail();
            print_r("customer id:".$customerId. "Email:".$customerEmail) . "<br>";
        
            $customName = $customer->getName();
            $customEmail = $customer->getEmail();

            $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => 1); 
            $templateVars = [
                'name' => $customName , 
                'email' => $customEmail
            ]; 

      

    //    $sender=  $this->scopeConfig->getValue("Kitchen_Email/email/recipient_email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
    //    $reciver=  $this->scopeConfig->getValue("Kitchen_Email/email/reciver_email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
    //    $templates=  $this->scopeConfig->getValue("Kitchen_Email/email/email_template", \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ;
            
        

        // Email template 

        // Sender 

        // echo "<pre>";print_r($this->scopeConfig->getValue( 

        //     'trans_email/ident_'.$dynamic, 

        //     \Magento\Store\Model\ScopeInterface::SCOPE_STORE, 

        // ));

         $transport = $this->_transportBuilder->setTemplateIdentifier('Kitchen_Email_email_email_template') 
            ->setTemplateOptions($templateOptions) 
            ->setTemplateVars($templateVars) 
            ->setFrom([ 
                'name' => 'Test', 
                'email' => 'disha@gmail.com' 
            ]) 
            ->addTo([$customerEmail]) 
            // ->addCc(['']) 
            // ->addBcc(['bipin@kitchen365.com']) 
            ->getTransport(); 
        $transport->sendMessage(); 
        $this->inlineTranslation->resume();
            } 
    }
}
