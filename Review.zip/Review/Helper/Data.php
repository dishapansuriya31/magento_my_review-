<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kitchen\Review\Helper;


use Magento\Framework\App\Helper\AbstractHelper;

/**
 * CMS Page Helper
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 */
class Data extends AbstractHelper
{
     /**
     * Filter manager
     *
     * @var \Magento\Framework\Filter\FilterManager
     */
    protected $filter;

    /**
     * Escaper
     *
     * @var \Magento\Framework\Escaper
     */
    protected $_escaper;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Escaper $escaper
     * @param \Magento\Framework\Filter\FilterManager $filter
     */
    public function __construct(
      \Magento\Framework\App\Helper\Context $context,
      \Magento\Framework\Escaper $escaper,
      \Magento\Framework\Filter\FilterManager $filter
  ) {
      $this->_escaper = $escaper;
      $this->filter = $filter;
      parent::__construct($context);
  }
    }
